const usePostHook = (props) => {
  return <></>;
};

export default usePostHook;
