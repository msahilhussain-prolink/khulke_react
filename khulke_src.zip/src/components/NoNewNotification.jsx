const NoNewNotification = () => {
    return (
     <div className="container text-center my-5 py-5">
        <small className="text-muted">No new notifications!</small>
    </div>
    )
}

export default NoNewNotification;