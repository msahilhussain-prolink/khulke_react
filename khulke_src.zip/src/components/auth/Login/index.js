import React from 'react';


const Login = () =>{
    return(
        <section>
            <h1>You've reached the login page!</h1>
        </section>
    )
}
export default Login;