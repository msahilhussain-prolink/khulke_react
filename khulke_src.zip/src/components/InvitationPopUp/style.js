export const dialogPaper = {
  borderRadius: "16px",
  border: "1px solid #00000029",
  boxShadow: "5px 5px 10px #0000001F",
};
