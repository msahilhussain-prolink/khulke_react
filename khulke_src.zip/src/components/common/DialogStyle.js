export const DialogStyle = {
    dialog: { 
        background: "black",
        color:"white"
 },
 icon: {color: "white"},
 dialogContent: {overflow:"hidden"}
}