import React from "react";

const Viewers = ({ height = "28", width = "28", color = "#ec5a61" }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      id="Group_24445"
      data-name="Group 24445"
      width={height}
      height={width}
      viewBox="0 0 28 28"
    >
      <rect
        id="Rectangle_2913"
        data-name="Rectangle 2913"
        width="28"
        height="28"
        fill="none"
      />
      <g
        id="Group_24526"
        data-name="Group 24526"
        transform="translate(1.75 6.123)"
      >
        <circle
          id="Ellipse_965"
          data-name="Ellipse 965"
          cx="5.688"
          cy="5.688"
          r="5.688"
          transform="translate(2.187 0.002)"
          fill="none"
          stroke={color}
          stroke-width="1"
        />
        <path
          id="Path_15317"
          data-name="Path 15317"
          d="M155.413,56.2a5.688,5.688,0,1,1,1.543,11.163"
          transform="translate(-140.164 -55.986)"
          fill="none"
          stroke={color}
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="1"
        />
        <path
          id="Path_15318"
          data-name="Path 15318"
          d="M16,164.09a9.627,9.627,0,0,1,15.751,0"
          transform="translate(-15.996 -148.623)"
          fill="none"
          stroke={color}
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="1"
        />
        <path
          id="Path_15319"
          data-name="Path 15319"
          d="M169.522,160a9.614,9.614,0,0,1,7.875,4.09"
          transform="translate(-152.73 -148.623)"
          fill="none"
          stroke={color}
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="1"
        />
      </g>
    </svg>
  );
};

export default Viewers;
